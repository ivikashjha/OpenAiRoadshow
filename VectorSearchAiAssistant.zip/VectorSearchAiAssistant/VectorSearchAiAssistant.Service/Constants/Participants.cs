namespace VectorSearchAiAssistant.Service.Constants;

public enum Participants
{
    User = 0,
    Assistant
}