﻿namespace Search.Helpers
{
    public class ChatManagerSettings
    {
        public required string APIUrl { get; set; }
        public required string APIRoutePrefix { get; set; }
    }
}
